public class Person {
  private String name;
  private int workingHour;
  private int skill;
  
  public Person() {  }
  
  public Person(String n, int wh, int s) {
    name = n;
    workingHour = wh;
    skill = s;
  }
  
  
  public int getWorkingHour() { return workingHour; }
  public int getSkill() { return skill; }
}