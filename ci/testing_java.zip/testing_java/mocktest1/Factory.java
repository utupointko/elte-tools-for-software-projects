import java.util.Vector;
import java.util.List;

public class Factory {
  private List<Person> workers = new Vector<Person>();
  PersonPersister pp;
  
  public void setPersister(PersonPersister p) {
    pp = p;    
  }
  
  public void open() {
    workers.add( pp.load("Jozsi") );
    workers.add( pp.load("Dezso") );
  }
  
  int getDailyProduction() {
    int sum = 0;
    for(Person pers: workers) {
      sum += pers.getWorkingHour() * pers.getSkill();
    }
    
    return sum;
  }
  
  
}