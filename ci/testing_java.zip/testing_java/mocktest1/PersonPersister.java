public class PersonPersister {
  Person load(String name) {
    Person person = new Person();
    // read person's properties from database
    // build person
    return person;
  }
}