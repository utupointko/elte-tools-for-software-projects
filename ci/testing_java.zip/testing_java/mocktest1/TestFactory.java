import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class TestFactory {
  
  Factory factory;
  PersonPersister mockedPersonPersister;
  
  @Before
  public void setup() {
    mockedPersonPersister = mock(PersonPersister.class);
    when(mockedPersonPersister.load("Jozsi")).thenReturn(
      new Person("Jozsi", 4, 3));
    when(mockedPersonPersister.load("Dezso")).thenReturn(
      new Person("Dezso", 8, 2));        
    
    factory = new Factory();
    factory.setPersister(mockedPersonPersister);
  }
  
  @Test
  public void productionTest() {            
    factory.open();
    assertEquals(28, factory.getDailyProduction());
        
    verify(mockedPersonPersister).load("Jozsi");
    verify(mockedPersonPersister).load("Dezso");
  }
}
