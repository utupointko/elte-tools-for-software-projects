import org.junit.Before;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestMiniMath {

  private MiniMath mm;


  @BeforeClass
  public static void globalSetup()
  {
    System.out.println("global setup");
  }

  @AfterClass
  public static void globalCleanup()
  {
    System.out.println("global cleanup");
  }

  @Before
  public void setup () {
    System.out.println("setup testcase");
    mm = new MiniMath();
  }

  @After
  public void cleanup () {
    System.out.println("cleanup testcase");
  }

  @Test
  public void testFactorial() {
    System.out.println("run testcase: factorial");

    assertNotNull(mm);

    assertEquals(120, mm.factorial(5));
    assertEquals(24, mm.factorial(4));
    assertEquals(1, mm.factorial(0));

  }

  @Test
  public void testgcd() {
    System.out.println("run testcase: gcd");

    assertNotNull(mm);

    assertEquals(4, mm.gcd(12,8));
    assertEquals(1, mm.gcd(14,27));
  }

  @Ignore
  @Test
  public void testdummy() {
    System.out.println("run testcase: dummy");
    assertTrue(true);
  }
}