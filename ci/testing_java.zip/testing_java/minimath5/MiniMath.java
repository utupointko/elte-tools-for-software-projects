
public class MiniMath {
  public int factorial(int n) {
    if(n<0)
      throw new ArithmeticException();
    int res = 1;
    for(int i=2; i<=n; ++i)
      res *= i;
    return res;
  }

  public int gcd(int a, int b) {
    while(a != b) {
      if(a > b)
        a -= b;
      else
        b -= a;
    }
    return a;
  }

  public int fibonacci(int n){
    if(n==0)
      return 0;
    if(n==1)
      return 1;

    return fibonacci(n-1) + fibonacci(n-2);
  }
}
