import org.junit.Test;
import static org.junit.Assert.*;

public class TestMiniMath {
  @Test
  public void testFactorial() {
    MiniMath mm = new MiniMath();

    assertNotNull(mm);

    assertEquals(120, mm.factorial(5));
    assertEquals(24, mm.factorial(4));
    assertEquals(1, mm.factorial(0));

  }
}