import org.junit.Before;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestMiniMath {

  private MiniMath mm;

  @Before
  public void setup () {
    mm = new MiniMath();
  }

  @Test
  public void testFactorial() {
    assertNotNull(mm);

    assertEquals(120, mm.factorial(5));
    assertEquals(24, mm.factorial(4));
    assertEquals(1, mm.factorial(0));
  }

  @Test
  public void testgcd() {
    assertNotNull(mm);

    assertEquals(4, mm.gcd(12,8));
    assertEquals(1, mm.gcd(14,27));
  }

  @Test(timeout=10)
  public void testFibonacci() {
    assertEquals(2, mm.fibonacci(3));
    assertEquals(21, mm.fibonacci(8));
    assertEquals(3524578, mm.fibonacci(33));
  }
}

//0 1 1 2 3 5 8 13 21 34 55 89