import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
   TestMiniMath1.class,
   TestMiniMath2.class
})
public class TestSuiteMath {
}