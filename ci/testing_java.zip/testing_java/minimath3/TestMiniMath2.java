import org.junit.Before;
import org.junit.After;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestMiniMath2 {

  private MiniMath mm;


  @BeforeClass
  public static void globalSetup()
  {
    System.out.println("global setup in TestMiniMath2");
  }

  @AfterClass
  public static void globalCleanup()
  {
    System.out.println("global cleanup in TestMiniMath2");
  }

  @Before
  public void setup () {
    System.out.println("setup testcase in TestMiniMath2");
    mm = new MiniMath();
  }

  @After
  public void cleanup () {
    System.out.println("cleanup testcase in TestMiniMath2");
  }

  @Test
  public void testFactorial() {
    System.out.println("run testcase: factorial in TestMiniMath2");

    assertNotNull(mm);

    assertEquals(720, mm.factorial(6));
    assertEquals(6, mm.factorial(3));
    assertEquals(1, mm.factorial(1));

  }
}