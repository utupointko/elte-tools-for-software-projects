#include <gmock/gmock.h>
#include <gtest/gtest.h>

#include <string>
#include <memory>

#include "personpersister.h"
#include "factory.h"

using ::testing::Return;
class Person;

class MockPersonPersister : public PersonPersister
{
public:
  MOCK_METHOD1(load, std::shared_ptr<Person>(const std::string& name));

};

TEST(FactoryTest, dailyProduction)
{
  MockPersonPersister pp;
  EXPECT_CALL(pp, load("Jozsi")).WillOnce(Return( std::shared_ptr<Person>( new Person("Jozsi", 4, 3 ))));
  EXPECT_CALL(pp, load("Dezso")).WillOnce(Return( std::shared_ptr<Person>( new Person("Dezso", 8, 2 ))));

  Factory f;
  f.setPersister(&pp);
  f.open();

  EXPECT_EQ(28, f.getDailyProduction());

}

int main(int argc, char **argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
