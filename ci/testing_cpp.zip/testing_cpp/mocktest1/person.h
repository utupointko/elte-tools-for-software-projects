#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person
{
public:
  Person() { }

  Person(const std::string& n, int wh, int s) :
    name(n), workingHour(wh), skill(s) { }

  int getWorkingHour() { return workingHour; }
  int getSkill() { return skill; }

//private:
  std::string name;
  int workingHour;
  int skill;

};

#endif