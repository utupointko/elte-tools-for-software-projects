#ifndef FACTORY_H
#define FACTORY_H

#include <list>
#include <memory>
#include <iostream>

class Person;
class PersonPersister;

class Factory
{
public:

  void setPersister(PersonPersister* p)
  {
    pp = p;
  }

  void open()
  {
    workers.push_back( pp->load("Jozsi") );
    workers.push_back( pp->load("Dezso") );
  }

  int getDailyProduction()
  {
    int sum = 0;
    for(auto worker: workers)
    {
      sum += worker->getWorkingHour() * worker->getSkill();
    }

    return sum;
  }

private:
  std::list<std::shared_ptr<Person> > workers;
  PersonPersister* pp;

};

#endif
