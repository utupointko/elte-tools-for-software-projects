#ifndef PERSONPERSISTER_H
#define PERSONPERSISTER_H

#include <memory>
#include <string>

#include "person.h"

class PersonPersister
{
public:
  virtual std::shared_ptr<Person> load(const std::string& name)
  {
    std::shared_ptr<Person> person (new Person());
    // read person's properties from database
    // build person
    return person;
  }
};

#endif