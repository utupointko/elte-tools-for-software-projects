#ifndef MINIMATH_H
#define MINIMATH_H

class MiniMath
{
public:
  int factorial(int n);
};

#endif