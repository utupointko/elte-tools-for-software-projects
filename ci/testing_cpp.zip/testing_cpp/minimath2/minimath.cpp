#include "minimath.h"

int MiniMath::factorial(int n)
{
  int res = 1;
  for(int i=2; i<=n; ++i)
    res *= i;
  return res;

}

int MiniMath::lnko(int a, int b)
{
  while( a != b )
  {
    if( a > b )
      a -= b;
    else
      b -= a;
  }

  return a;
}